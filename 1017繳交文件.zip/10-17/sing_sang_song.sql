-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- 主機: 127.0.0.1
-- 產生時間： 2018-10-16: 20:23:38
-- 伺服器版本: 5.6.17
-- PHP 版本： 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 資料庫： `sing sang song`
--

-- --------------------------------------------------------

--
-- 資料表結構 `check_log`
--

CREATE TABLE IF NOT EXISTS `check_log` (
  `check_id` int(11) NOT NULL AUTO_INCREMENT,
  `manag_id` int(11) NOT NULL,
  `file_id` int(11) NOT NULL,
  `mesg_id` int(11) NOT NULL,
  `check` tinyint(1) NOT NULL,
  PRIMARY KEY (`check_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 資料表結構 `file`
--

CREATE TABLE IF NOT EXISTS `file` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `file_cont` longblob NOT NULL,
  `file_word` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `file_owner` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `file_classifi` text COLLATE utf8_unicode_ci NOT NULL,
  `prog_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '公開1',
  `CC` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 資料表結構 `manager`
--

CREATE TABLE IF NOT EXISTS `manager` (
  `manag_id` int(11) NOT NULL AUTO_INCREMENT,
  `manag_name` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `manag_acc` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `manag_paswd` int(50) NOT NULL,
  KEY `manag_id` (`manag_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='管理者' AUTO_INCREMENT=3 ;

--
-- 資料表的匯出資料 `manager`
--

INSERT INTO `manager` (`manag_id`, `manag_name`, `manag_acc`, `manag_paswd`) VALUES
(1, '', 'aaa', 123),
(2, '', '', 0);

-- --------------------------------------------------------

--
-- 資料表結構 `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `mesg_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `mesg_cont` text COLLATE utf8_unicode_ci NOT NULL,
  `mesg_datetime` datetime NOT NULL,
  `prog_id` int(11) NOT NULL,
  PRIMARY KEY (`mesg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='留言' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 資料表結構 `program`
--

CREATE TABLE IF NOT EXISTS `program` (
  `prog_id` int(11) NOT NULL AUTO_INCREMENT,
  `prog_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `prog_intro` text COLLATE utf8_unicode_ci NOT NULL,
  `prog_upload` longblob NOT NULL,
  `pay` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '公開1',
  PRIMARY KEY (`prog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 資料表結構 `prog_memb`
--

CREATE TABLE IF NOT EXISTS `prog_memb` (
  `memb_id` int(11) NOT NULL,
  `prog_id` int(11) NOT NULL,
  `comp` tinyint(1) NOT NULL,
  PRIMARY KEY (`memb_id`,`prog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 資料表結構 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `user_phone` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `user_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `user_acc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `user_paswd` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `credit` int(11) NOT NULL,
  `cookie` int(11) NOT NULL,
  `pic` blob NOT NULL COMMENT '大頭貼',
  `status` tinyint(1) NOT NULL COMMENT '公開1',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=75 ;

--
-- 資料表的匯出資料 `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_phone`, `user_email`, `user_acc`, `user_paswd`, `credit`, `cookie`, `pic`, `status`) VALUES
(1, '權自龍', '0975367833', '123@gmail.com', '123', '321', 0, 0, '', 0),
(3, 'Lin', '0975367881', 'c90813@gmail.com', 'c90813', 'dsrt3310', 0, 0, '', 0),
(4, 'lin', '0975345127', 'c90813@gmail.com', 'dffddd', '2323', 0, 0, '', 0),
(11, '林欣蓉', '0946749119', 'c90813@gmail.com', 'z11077', 'dsrt3149', 0, 0, '', 0),
(12, '林欣蓉', '0946749119', 'c90813@gmail.com', 'z11077', '', 0, 0, '', 0),
(13, '林欣蓉', '0875432446', 'c90813@gjsia.com', 'efq3r3', '', 0, 0, '', 0),
(19, '林欣蓉', '0954787733', 'c90814@gmail.com', 'accdjie', '233yhuhid', 0, 0, '', 0),
(20, '林欣蓉', '0977736363', 'm4mp61999@gmail.com', 'account', 'm4mp61999', 0, 0, '', 0),
(55, 'fdsafdsa', 'sfadaf', 'fdf43qr', 'dsfdsa', 'fdafad', 0, 0, '', 0),
(56, 'fdsafdsa', 'sfadaf', 'fdf43qr', 'dsfdsa', 'fdafad', 0, 0, '', 0),
(57, '', '', '', '', '', 0, 0, '', 0),
(58, '', '', '', '', '', 0, 0, '', 0),
(59, '陳紹興', '0975642280', 'pnpmwpig@gmail.com', 'zed0204', '123456789', 0, 0, '', 0),
(60, '陳紹興', '0975642280', 'pnpmwpig@gmail.com', 'zed0204', '1', 0, 0, '', 0),
(61, '', '', '', '', '', 0, 0, '', 0),
(62, '', '', '', '', '', 0, 0, '', 0),
(63, '654', '', '', '', '', 0, 0, '', 0),
(64, '', '', '', '', '', 0, 0, '', 0),
(65, '', '', '', '', '', 0, 0, '', 0),
(66, '', '', '', '', '', 0, 0, '', 0),
(67, '', '', '', '', '', 0, 0, '', 0),
(68, 'pig', '0988765448', '123456789@gamil.com', '321', '321', 0, 0, '', 0),
(69, '', '', '', '', '', 0, 0, '', 0),
(70, '', '', '', '', '', 0, 0, '', 0),
(71, '', '', '', '', '', 0, 0, '', 0),
(72, '', '', '', '', '', 0, 0, '', 0),
(73, '', '', '', '', '', 0, 0, '', 0),
(74, '', '', '', '', '', 0, 0, '', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
